# m2 🟡 gene_score 文档字符串提及不存在的"强势率"

## 问题定位

- **代码文件**: `src/algorithms/irs/pipeline.py` (line 9)

## 差异描述

### 当前 docstring

```python
# pipeline.py:9
#   6. gene_score — 基因（涨停率 + 新高率 + 强势率）
```

### 实际计算

gene_score 只包含两个子因子：
1. `gene_limit_ratio` — 涨停率（limit_up_count / stock_count）
2. `gene_high_ratio` — 新高率（new_100d_high_count / stock_count）

不存在第三个"强势率"子因子。设计文档 §3.6 也只定义了这两个。

## 修复方案

```python
# 修改 pipeline.py:9
#   6. gene_score — 基因（涨停率 + 新高率）
```

## 风险

无。纯文档修正。
