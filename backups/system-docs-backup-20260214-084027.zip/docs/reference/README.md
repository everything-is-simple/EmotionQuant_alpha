# 参考资料索引（docs/reference）

**版本**: v1.0
**最后更新**: 2026-02-04
**定位**: 外部资料与历史参考，不作为设计规范

---

## 权威来源（以此为准）

- 设计规范：`../design/`
- 治理规范：`../../Governance/steering/`
- 路线图：`../../Governance/Capability/`

---

## 目录结构

- `A股市场/`：A 股交易规则与行业分类参考
- `tushare/`：TuShare 配置与接口参考
- `workflows/`：外部流程参考索引（非治理口径）
- `市场情绪监控表/`：参考截图与素材
- `SwClass/`：申万行业分类原始资料
- `astock-rules-handbook.md`：A 股规则与 TuShare 映射手册（参考）

---

## 使用说明

- 本目录内容以“参考”为目的，若与 `docs/design/` 或 `Governance/` 冲突，以上级文档为准。
- 需要历史内容可通过 Git 历史版本追溯。

